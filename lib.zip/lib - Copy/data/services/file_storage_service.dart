import 'dart:io';

import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import 'dart:typed_data';
import '../../core/constants/app_constants.dart';
import '../../core/errors/app_exceptions.dart';

class FileStorageService {
  final Uuid uuid;

  FileStorageService({
    Uuid? uuid,
  }) : uuid = uuid ?? const Uuid();

  Future<Directory> _getDocumentsDirectory() async {
    try {
      return await getApplicationDocumentsDirectory();
    } catch (e) {
      throw FileStorageException(
        'Unable to access application storage.',
      );
    }
  }

  Future<Directory> _getStorageDirectory({
    required bool isPdf,
  }) async {
    final appDirectory = await _getDocumentsDirectory();

    final folderName = isPdf
        ? AppConstants.pdfsFolder
        : AppConstants.imagesFolder;

    final directory = Directory(
      path.join(appDirectory.path, folderName),
    );

    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }

    return directory;
  }

  Future<String> saveFile({
    required File sourceFile,
    required bool isPdf,
  }) async {
    try {
      final directory = await _getStorageDirectory(
        isPdf: isPdf,
      );

      final extension = path.extension(sourceFile.path);

      final uniqueFileName = '${uuid.v4()}$extension';

      final destinationPath = path.join(
        directory.path,
        uniqueFileName,
      );

      final savedFile = await sourceFile.copy(
        destinationPath,
      );

      return savedFile.path;
    } catch (e) {
      throw FileStorageException(
        'Failed to save file: $e',
      );
    }
  }
  Future<String> saveEncryptedBytes({
    required Uint8List encryptedBytes,
    required bool isPdf,
    String originalExtension = '.enc',
  }) async {
    try {
      final directory = await _getStorageDirectory(
        isPdf: isPdf,
      );

      final uniqueFileName = '${uuid.v4()}$originalExtension';

      final destinationPath = path.join(
        directory.path,
        uniqueFileName,
      );

      final file = File(destinationPath);

      await file.writeAsBytes(
        encryptedBytes,
        flush: true,
      );

      return file.path;
    } catch (e) {
      throw FileStorageException(
        'Failed to save encrypted file: $e',
      );
    }
  }
  Future<void> deleteFile(String filePath) async {
    try {
      final file = File(filePath);

      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      throw FileStorageException(
        'Failed to delete file: $e',
      );
    }
  }

  Future<bool> fileExists(String filePath) async {
    return File(filePath).exists();
  }

  /// Deletes PocketDocs files that are no longer part of
  /// the restored database.
  ///
  /// Files whose paths are present in [keepPaths] are preserved.
  Future<void> clearStorageExcept(
      Set<String> keepPaths,
      ) async {
    try {
      final appDirectory = await _getDocumentsDirectory();

      final storageFolders = [
        AppConstants.imagesFolder,
        AppConstants.pdfsFolder,
      ];

      for (final folderName in storageFolders) {
        final directory = Directory(
          path.join(
            appDirectory.path,
            folderName,
          ),
        );

        if (!await directory.exists()) {
          continue;
        }

        await for (final entity in directory.list()) {
          if (entity is File && !keepPaths.contains(entity.path)) {
            await entity.delete();
          }
        }
      }
    } catch (e) {
      throw FileStorageException(
        'Failed to clean PocketDocs storage: $e',
      );
    }
  }
}